﻿namespace customcredits
{
    /// <summary>
    /// This class is used to provide information about your mod to BepInEx.
    /// </summary>
    internal class PluginInfo
    {
        public const string GUID = "com.striker.gorillatag.customcredits";
        public const string Name = "customcredits";
        public const string Version = "1.0.0";
    }
}
